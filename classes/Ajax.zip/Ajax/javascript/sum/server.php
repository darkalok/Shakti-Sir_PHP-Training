<?php
  $n1 = $_REQUEST['n1'];
  $n2 = $_REQUEST['n2'];
  echo $n1+$n2;
?>