<?php
  # Create Array
  $arr = array(101,"Sameer","BCA");
  echo $arr[0]."<br/>";
  echo $arr[1]."<br />";
  echo $arr[2]."<br />";
  #print_r only use in array
  print_r($arr);
?>