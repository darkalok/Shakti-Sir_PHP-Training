<?php
  $a = 10;
  var_dump($a);
  print "<br/>";
  $arr = array(101,"Sameer",12.2,true);
  var_dump($arr);
?>