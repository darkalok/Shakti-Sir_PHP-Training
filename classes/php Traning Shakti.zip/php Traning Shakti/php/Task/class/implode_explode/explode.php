<?php
  $str = "Sameer Singh";
  echo $str." = ".gettype($str)."<br />";
   $arr = explode(" ",$str);
   print_r($arr);
?>