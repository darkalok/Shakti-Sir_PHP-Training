<form action="server.php" method="post">
   <label for="city">City</label>
   <input type="text" name="city" required />
   <br />
   <label for="state">State</label>
   <input type="text" name="state" required />
   <br />
   <input type="submit" value="next" />
   <input type="hidden" name="act" value="a_data" />
</form>