<form action="server.php" method="post">
   <label for="u_name">Username</label>
   <input type="text" name="u_name" required />
   <br />
   <label for="co">c/o</label>
   <input type="text" name="co" required />
   <br />
   <input type="submit" value="next" />
   <input type="hidden" name="act" value="p_data" />
</form>