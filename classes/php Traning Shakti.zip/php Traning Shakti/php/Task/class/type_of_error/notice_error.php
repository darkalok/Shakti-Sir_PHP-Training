<?php
//  Notice Error
//   $a = 10;
echo $a;
?>