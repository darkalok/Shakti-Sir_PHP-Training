<?php
   #head line comment
   #below line used to display welcome

   // single line comment
   // echo "Welcome1 <br />";

   /* multiline comment */
   /*echo "Welcome2 <br />";
      echo "Welcome3 <br />"; */

      echo "Welcome 4";
?>