<?php
  require("header.php");
  echo "Hi I am C";
  require("footer.php");
?>