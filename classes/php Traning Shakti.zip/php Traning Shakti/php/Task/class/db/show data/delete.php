<?php
  include ("db_connect.php");
  $e_id = $_REQUEST['e_id'];
?>