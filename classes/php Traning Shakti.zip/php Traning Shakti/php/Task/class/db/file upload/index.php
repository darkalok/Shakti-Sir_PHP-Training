<form action="server.php" method="post" enctype="multipart/form-data">
  Photo
  <input type="file" name="f" />
  <input type="submit" value="upload" />
</form>