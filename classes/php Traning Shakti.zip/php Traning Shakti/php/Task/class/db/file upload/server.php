<?php
  require("db_connect.php");

?>