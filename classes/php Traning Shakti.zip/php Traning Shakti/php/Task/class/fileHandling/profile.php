<?php
  echo "welcome user";
?>