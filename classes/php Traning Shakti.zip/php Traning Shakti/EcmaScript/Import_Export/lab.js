const x = require('./useme');
console.log(x.a);