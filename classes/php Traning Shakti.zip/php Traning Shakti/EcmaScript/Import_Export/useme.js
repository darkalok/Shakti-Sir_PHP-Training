export let a=10;
export function show(){
   console.log("show function");
}
export default function display(){
   console.log("display function");
}