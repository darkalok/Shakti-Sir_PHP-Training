<?php
//   Falat error
function show(){
   echo "call function";
}
sho();
?>