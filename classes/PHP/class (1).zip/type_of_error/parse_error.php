<?php
//   Parse or Syntax error
echo "Start<br />";
echo "welcome <br />;
echo "end"; 
?>