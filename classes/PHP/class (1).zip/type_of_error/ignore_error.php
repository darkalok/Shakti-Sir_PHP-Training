<?php
// ignore Error
error_reporting(0);
  echo "Strat <br />";
  echo $a;
  echo "End";
?>