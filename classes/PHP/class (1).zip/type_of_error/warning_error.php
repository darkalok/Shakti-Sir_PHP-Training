<?php
   include('index.php')
?>