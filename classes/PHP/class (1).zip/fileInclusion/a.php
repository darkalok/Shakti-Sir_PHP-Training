<?php
  include("header.php");
  echo "Hi I am A";
  require("footer.php");
?>
