<?php
  require("header.php");
  echo "Hi I am B";
  require("footer.php");
?>