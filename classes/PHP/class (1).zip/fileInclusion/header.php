<a href="a.php">For A</a>
<a href="b.php">For B</a>
<a href="c.php">For C</a>
<hr />
