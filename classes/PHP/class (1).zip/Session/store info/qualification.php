<form action="server.php" method="post">
   <label for="course">Coures</label>
   <input type="text" name="course" required />
   <br />
   <label for="duriation">Duriation</label>
   <input type="text" name="duriation" required />
   <br />
   <input type="submit" value="next" />
   <input type="hidden" name="act" value="q_data" />
</form>