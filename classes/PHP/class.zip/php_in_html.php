<?php
   echo "<font color='red'>php in html<font>";
?>