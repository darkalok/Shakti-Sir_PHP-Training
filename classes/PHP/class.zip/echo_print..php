<?php
   # difference between echo and print

   // echo display multiple value in one time 
   echo "Hello"," Sameer";
   // print display only single value in one time
   print "Hello";

   # print always return value
   $a = print("hii");
   echo $a;
?>