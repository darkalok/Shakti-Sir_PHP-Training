<?php
// Define Variiable
  $a = 10;
  $b = 12.3;
  $c = 'php';
  $d = true;

// get type of variable
  echo gettype($a)." = ".$a."<br />";
  echo gettype($b)." = ".$b."<br />";
  echo gettype($c)." = ".$c."<br />";
  echo gettype($d)." = ".$d."<br />";
?>