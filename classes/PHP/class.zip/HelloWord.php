<!-- Hello Word in php -->

<?php
  echo "Hello word";
?>