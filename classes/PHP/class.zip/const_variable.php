<?php
# create const type variable useing define

// variable name HOST and value is localhost
   define("HOST", "localhost");
   define("DB","stdb");
   echo HOST." ".DB;
?>