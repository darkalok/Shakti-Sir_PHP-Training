<?php
   $a = 10;
   $b = 12.3;
   $c = 'php';
   $d = true;

   echo $a."<br />";
   echo $b."<br />";
   echo $c."<br />";
   echo $d."<br />";
?>